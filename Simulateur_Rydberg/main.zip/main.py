import numpy as np
import matplotlib.pyplot as plt
import sys

######################################################## FONCTIONS ########################################################

# Cette fonction mange un nombre L d'atomes et retourne une liste de vecteurs (donc une matrice) binaires avec toutes les combinaisons de
# 0 et 1 POSSIBLES pour un L donné (il y a donc moins de 2^L vecteurs en tout, car quand deux "1" se suivent, le vecteur ket n'est pas
# possible).
def all_possible_vectors_generation(L):
#### Création d'une matrice contenant toutes les possibilités, mêmes les configurations impossibles ####
    all_vectors = np.zeros((2 ** L, L), dtype=int)

    for i in range(2 ** L):
        for j in range(L):
            # On extrait le j-ème bit
            all_vectors[i, (L-1) - j] = (i >> j) & 1


#### Identification des indices des configurations POSSIBLES ####
    sorted_vectors = [] # liste qui contiendra uniquement les vecteurs des configurations POSSIBLES
    sorted_indices = []
    index = 0

    for i in range(all_vectors.shape[0]):
        index = i
        for j in range(all_vectors.shape[1]):
            if j == 0 and all_vectors[i, 0] == 1 and all_vectors[i, 1] == 1:
                # si |1 1...>, alors on met index = -1
                index = -1

            elif j == (all_vectors.shape[1] - 1) and all_vectors[i, (all_vectors.shape[1] - 2)] == 1 and all_vectors[i, all_vectors.shape[1] - 1] == 1:
                # si |...1 1>, alors on met index = -1
                index = -1

            elif j != 0 and j != (all_vectors.shape[1] - 1) and all_vectors[i, (j - 1)] == 1 and all_vectors[i, j] == 1  or  j != 0 and j != (all_vectors.shape[1] - 1) and all_vectors[i, j] == 1 and all_vectors[i, (j + 1)] == 1:
                # si j != 0 et j != (2^L - 1) et |...1 1...> ou j != 0 et j != (2^L - 1) et |...1 1...>, alors on met index = -1
                index = -1

        if index != -1: # si index != -1, alors la configuration est possible et on range le vecteur correspondant dans la liste sorted_vectors
            sorted_indices.append(index)
            sorted_vectors.append(all_vectors[index])

    return np.array(sorted_indices), np.array(sorted_vectors)

# Exemple i=10
'''
i >> j: décalage binaire vers la droite de j positions: 10 >> 1
i = 10 (0b001010)  (on met le préfixe "0b" pour préciser que le nombre suivant est en binaire car "b" comme " binaire")

10 >> 0 -> 0b001010 (reste identique)
10 >> 1 -> 0b000101
10 >> 2 -> 0b000010
10 >> 3 -> 0b000001
10 >> 4 -> 0b000000
10 >> 5 -> 0b000000


x & 1: garde le dernier bit de x

10 & 1 -> 0b001010 & 000001 = 0 (car le dernier bit (à droite) de 10 est 0)
21 & 1 -> 0b010101 & 000001 = 1 (car le dernier bit de 21 est 1)
etc...
'''

###########################################################
# Cette fonction mange un vecteur ket |Ψ> de taille L et rend un tableau np de vecteurs (donc une matrice) qui constituent les termes de
# la C.L de H|Ψ>, où H est la matrice hamiltonienne du sytème
def CL_H_psi(vect_binaire):
    H_psi_mat = []  #matrice qui contient les vecteurs de la C.L
    vect_tampon = np.copy(vect_binaire) # ATTENTION: il faut utiliser copy car sinon on égale les références des deux tableaux et donc si on
                                        # modifiait vect_tampon, vect_binaire se modifiait aussi

#### Transformation des 0 en 1 si possible ####
    for j in range(vect_binaire.shape[0]):
        if j == 0 and vect_binaire[0] == 0 and vect_binaire[1] == 0:  # Si |0 0 ...>, alors on construit |1 0 ...>
            vect_tampon[0] = 1
            H_psi_mat.append(vect_tampon)
            vect_tampon = np.copy(vect_binaire) # On réinitialise le vecteur tampon au vecteur binaire |Ψ>

        if j == (vect_binaire.shape[0] - 1) and vect_binaire[vect_binaire.shape[0] - 2] == 0 and vect_binaire[vect_binaire.shape[0] - 1] == 0:
            # Si |...0 0>, alors on construit |...0 1>
            vect_tampon[vect_binaire.shape[0] - 1] = 1
            H_psi_mat.append(vect_tampon)
            vect_tampon = np.copy(vect_binaire)  # On réinitialise le vecteur tampon au vecteur binaire |Ψ>

        if j != 0 and j != (vect_binaire.shape[0] - 1) and vect_binaire[j-1] == 0 and vect_binaire[j] == 0  and vect_binaire[j+1] == 0:
            # Si |...0 0 0...>, alors on construit |...0 1 0...>
            vect_tampon[j] = 1
            H_psi_mat.append(vect_tampon)
            vect_tampon = np.copy(vect_binaire)  # On réinitialise le vecteur tampon au vecteur binaire |Ψ>


#### Transformation des 1 en 0 ####
    for j in range(vect_binaire.shape[0]):
        if vect_binaire[j] == 1:
            vect_tampon[j] = 0
            H_psi_mat.append(vect_tampon)
            vect_tampon = np.copy(vect_binaire)

    return np.array(H_psi_mat)


###########################################################
# Cette fonction mange une matrice contenant plusieurs vecteurs binaires de taille L et rend un vecteur binaire de taille (2^L - nbre de
# configurations impossibles) contenant des "1" aux positions qui correspondent aux nombres décimaux des nombres binaires contenus dans
#  les vecteurs binaires de la matrice passée en argument
def H_psi(H_psi_mat):
    all_indices, all_vectors = all_possible_vectors_generation(H_psi_mat.shape[1])
    H_psi_binaire = np.zeros(all_indices.shape[0]) # vecteur remplis de 0 de taille (2^L - nbre de configurations impossibles)


    for i in range(H_psi_mat.shape[0]):
        for k in range(all_vectors.shape[0]): # k ∈ {0,...,20}
            if np.array_equal(H_psi_mat[i] , all_vectors[k]):
                H_psi_binaire[k] = 1


    return H_psi_binaire


###########################################################
# Cette fonction mange un nombre L d'atomes et rend le Hamiltonien qui ne possède que les configurations POSSIBLES du système
def get_hamiltonian(L):
    all_indices, all_vectors = all_possible_vectors_generation(L)
    dim_H = all_indices.shape[0]
    H = np.zeros((dim_H,dim_H))

    for i in range(dim_H):
        ket_i = all_vectors[i] # On récupère le ket |i> parmi la matrice all_vectors qui contient tous les vecteurs binaires possibles,
                               # ce vecteur est de taille L
        H_ket_i_mat = CL_H_psi(ket_i) # Matrice contenant les vecteurs (de taille L) obtenus en prenant en compte toutes les configurations
                                      # possibles en partant du ket |i>
        ket_H_psi = H_psi(H_ket_i_mat) # Conversion en indices binaires; vecteur de taille (2^L - nbre de configurations impossibles)
                                       # avec des 1 et plein de 0

        for j in range(ket_H_psi.shape[0]):
            if ket_H_psi[j] == 1:  # Si la transition du ket |i> vers le ket |j> est possible
                H[i, j] = 1  # On peut mettre le coefficient correspondant dans le Hamiltonien

    return H

'''
Si nombres est une liste, par exemple nombres = [10, 20, 30, 40, 50], alors la fonction enumerate(nombres), transformer cette liste en une
autre liste de couple (indice , valeur)

--> enumerate(nombres) va produire [(0,10), (1, 20), (2, 30), (3, 40), (4,50)]
'''


###########################################################
# Cette fonction effectue le produit d'une matrice M1 avec une matrice M2 et rend la matrice résultante
def prod_mat(M1 , M2):
    if M1.shape[1] != M2.shape[0]:
        print("ERREUR : le nombre de colonnes de M1 n'est pas égal au nombre de lignes de M2.")
        sys.exit(1)  # Quitte le programme avec un code d'erreur

    else:
        result = np.zeros((M1.shape[0] , M2.shape[1]))

        for i in range(M1.shape[0]):
            for j in range(M2.shape[1]):
                for k in range(M1.shape[1]):
                    if M1[i,k] != 0 and M2[k,j] != 0:
                        result[i,j] = result[i,j] + (M1[i,k] * M2[k,j]) # On complète result[i,j] ligne par ligne
    return result


###########################################################
# Cette fonction effectue le produit d'une matrice avecc un vecteur et rend le vecteur résultant
def prod_mat_vect(M , v):
    if M.shape[1] != v.shape[0]:
        print("ERREUR : le produit matrice-vecteur n'est pas défini.")
        sys.exit(1)  # Quitte le programme avec un code d'erreur

    else:
        result = np.zeros(M.shape[0] , dtype=complex)

        for i in range(M.shape[0]):
            for j in range(v.shape[0]):
                if M[i,j] != 0:
                    result[i] = result[i] + (M[i,j] * v[j])

    return result


###########################################################
# Cette fonction calcule la factorielle de n
def factorielle(n):
    if n < 0:
        raise ValueError("La factorielle n'est pas définie pour les nombres négatifs.")
    elif n == 0 or n == 1:
        return 1
    else:
        return n* factorielle(n-1)


###########################################################
# Cette fonction mange un Hamiltonien, une fonction psi initiale, un intervalle de temps dt et un nombre naturel K qui est le terme de la
# série que l'on tronquera et rend la fonction d'onde à un instant t = t_0 + dt "un peu plus éloigné" que t_0
def compute_psi_t(H , psi_0 , dt , K):
    psi_t = np.copy(psi_0)
    H_k = np.zeros((H.shape[0] , H.shape[1]))

    for n in range(H_k.shape[0]): # On initialise H_k à l'identité
        H_k[n,n] = 1

#### Calcul de psi à l'instant t_0 + dt ###
    for k in range(1 , K+1): # On commence à k=1 et on finit à k=K car on a déjà initialisé psi_t à psi_0
        H_k = prod_mat(H_k, H) # On calcule H^k
        psi_t = np.copy(psi_t) + (((-1j * dt) ** k) / factorielle(k)) * prod_mat_vect(H_k , psi_0)

    return psi_t


###########################################################
# Cette fonction convertit tout nombre decimal n en un vecteur qui définit sa représentation binaire
def decimal_to_binary(n, L):
    #Si le nombre n est négatif, on en veut pas
    if n < 0:
        raise ValueError("Le nombre doit être positif ou nul.")

    binaire = bin(n)[2:]  # Convertit en binaire et enlève le "0b" avant le string bin(n)
    liste_binaire = []  # Liste vide pour stocker les bits

    for bit in binaire:  # Boucle sur chaque caractère binaire
        liste_binaire.append(int(bit))  # Convertit en entier et ajoute à la liste

    while(len(liste_binaire) != L):
        liste_binaire.insert(0,0)

    return np.array(liste_binaire)


###########################################################
# Cette fonction mange un vecteur binaire de dimension L et rend le nombre décimal lui correspondant
def binary_to_decimal(vect_binaire):
    decimal_number = 0
    for i in range(len(vect_binaire)):
        decimal_number = decimal_number + vect_binaire[i]*(2 ** ((len(vect_binaire)-1)-i))
    return decimal_number


###########################################################
def dim_L_to_dim_n(vect_binaire, all_indices):
    decimal_number = binary_to_decimal(vect_binaire)
    psi = np.zeros(all_indices.shape[0])
    for i in range(all_indices.shape[0]):
        if decimal_number == all_indices[i]:
            psi[i] = 1

    return psi


###########################################################
# Cette fonction mange une fonction d'onde de dimension 21, un nombre d'atomes L, un numéro d'atome f et une liste all_indices. Elle rend
# la moyenne de sigma_z de l'atome numero f
def sigma_z(psi, L, f, all_indices):

    n = 0
    mean_sigma_z_atom = 0

    for j in range(len(psi)):
        if psi[j] != 0:
            n = all_indices[j]
            vecteur = decimal_to_binary(n,L) # On converti le nombre decimal en vecteur binaire (vecteur est un vecteur tampon)

            if vecteur[f] == 0:
                mean_sigma_z_atom += (abs(psi[j])) ** 2

            else:
                mean_sigma_z_atom -= (abs(psi[j])) ** 2


    return mean_sigma_z_atom


###########################################################
def plot_and_save_1(x, y, titre, filename):
    plt.figure(figsize=(8, 5))
    plt.plot(x, y, linestyle='-', color='b', label="sum((sigma_z)_f * (sigma_z)_f+1)")

    # Ajout des titres et légendes
    plt.xlabel("temps (s)")
    plt.ylabel("moyenne de sigma_z")
    plt.title(titre)
    plt.legend()
    plt.grid(True)

    # Sauvegarde du graphique
    plt.savefig(filename, dpi=300)
    plt.close()  # Ferme la figure pour éviter d'afficher dans certains environnements


###########################################################
def plot_and_save_2(x, y1, y2, f1, f2, titre, filename):
    # Création du graphique
    plt.figure(figsize=(8, 5))
    plt.plot(x, y1, linestyle='-', color='b', label="atome " + f1) # marker='o' fait que l'on plot les points avec ou non
    plt.plot(x, y2, linestyle='-', color='r', label="atome " + f2)


    # Ajout des titres et légendes
    plt.xlabel("temps (s)")
    plt.ylabel("moyenne de sigma_z")
    plt.title(titre)
    plt.legend()
    plt.grid(True)

    # Sauvegarde du graphique
    plt.savefig(filename, dpi=300)
    plt.close()  # Ferme la figure pour éviter d'afficher dans certains environnements


###########################################################








######################################################## MAIN ########################################################

L = 6 # Nombre d'atomes
f = 2 # Numéro du site
dt = 0.001 # Incrément de temps pour le calcul de psi_t
K = 20 # Terme de tronquage de la série
all_indices, all_vectors = all_possible_vectors_generation(L)
H = get_hamiltonian(L)
vect2 = dim_L_to_dim_n(np.array([1,0,1,0,1,0]), all_indices) # On construit le vecteur de dim 21 au lieu de dim 6

'''
# plot les graphiques en superposé de sigma_z des atomes 1 et 2
x = [] # Vecteur des points d'absice
y1 = []
y2 = []
psi_0 = compute_psi_t(H,vect2,0,20)

for i in range(1000):
    x.append(i*dt)
    psi_t = compute_psi_t(H,psi_0,dt,K)
    y1.append(sigma_z(psi_t, L, 1, all_indices))
    psi_0 = psi_t

psi_0 = compute_psi_t(H,vect2,0,20) # On réinitialise psi_0 pour le calcul de l'autre atome

for i in range(1000):
    # plus besoin d'append dans le x comme il a déjà été construit dans la boucle du haut
    psi_t = compute_psi_t(H,psi_0,dt,K)
    y2.append(sigma_z(psi_t, L, 2, all_indices))
    psi_0 = psi_t

titre = "Moyenne de sigma_z de au cours du temps"

plot_and_save(x, y1, y2, str(1), str(2), titre, filename="graph.png")
'''

x = []
y = []
y_i = 0 # Pour calculer le valeurs de spins actuels
psi_0 = compute_psi_t(H,vect2,0,20)

for i in range(10000):
    x.append(i * dt)
    psi_t = compute_psi_t(H, psi_0, dt, K)
    for f in range(5): # Boucle va jusque 5 pour éviter d'accéder à vecteur[6] (qui n'existe pas) dans la fonction sigma_z lorsque l'on fait "f+1"
        y_i = y_i + (sigma_z(psi_t, L, f, all_indices) * sigma_z(psi_t, L, f+1, all_indices))
    y.append(y_i)
    psi_0 = psi_t
    y_i = 0

titre = "sum((sigma_z)_f * (sigma_z)_f+1)"
filename = "Corr.png"

plot_and_save_1(x, y, titre, filename)









